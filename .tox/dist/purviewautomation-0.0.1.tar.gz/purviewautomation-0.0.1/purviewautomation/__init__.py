from purviewautomation.auth import ServicePrincipalAuthentication
from .collections import *
from .collections import * 
# test one
from purviewautomation import PurviewCollections


